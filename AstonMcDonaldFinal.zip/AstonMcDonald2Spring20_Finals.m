%% Spring 20 Finals (100 points)
%
% *Assigned on: 05/11/20 3:00 PM*
%
% *Notes*
%
% # *Deadline: 05/15/20 11:59 AM*
% # *Submit before the deadline*: delayed submissions will be penalized at
% 20% reduction in earned points
% # Please upload the *published document* as well as the *zipped folder* to
% canvas and download your submitted files to ensure we can reproduce your
% results
% # Look at the solution manuals for assignments. You are allowed to borrow
% functions from previous assignments.
%%
clear; clc; close all
fig = 0;
%% Problem 1: Root Finding and Optimization (30 points)
%
% You are given the following quadratic function:
%
% $f(x) = x^2 -3.5x +2$ 
%
% *1a (10 points)*
%
% Use the Newton-Raphson method to find one of the roots with an initial
% guess of |xinit = 4|, maximum iterations at 100, and tolerance at
% |1.E-6|. Report the root and number of iterations.
%
% *Answer*
i = 1;
x(i) = 4 ;
errNewt(i) = 1;
tol = 1.E-6;

while errNewt(i) > tol
    i = i + 1;
    fN =  ((x(i-1)).^2 - 3.5.*(x(i-1)) + 2);
    dfN = (2.*x(i-1) - 3.5);
    x(i) = x(i-1) - (fN/dfN);
    errNewt(i) = abs((x(i)-x(i-1))/x(i)).*100;
end

fprintf('The root from the Newton Raphson method is %6.4f in %4.2f iterations\n', x(i), i-1)
%
%%
% *1b (10 points)*
%
% Modify the function in *1a* so that you can use the Gradient-descent method to 
% find one of the roots with an initial guess of |xinit = 3|, maximum 
% iterations at 100, tolerance at |1.E-6|, and gamma ($\gamma$) value of
% 0.1.
% Report the root and number of iterations.
%
% *Answer*
f = @(x)(((x.^2 -3.5.*x +2).^2));

xopt = 3;
xopt_old = 1.2*xopt;

syms xsym
dh = matlabFunction(diff(f(xsym)));

i = 0;
maxi = 50;
tol = 1.E-6;
err = 1;
gamma = 0.1;

while err>tol && i < maxi
    xopt = xopt - gamma* dh(xopt);
    err = abs((xopt-xopt_old)/xopt);
    xopt_old = xopt;
    i = i+1;
    xopt_st(i) = xopt;
end

if (i<maxi)
    fprintf('Problem 1b:\nRoot at x = %4.5f after %d iterations with err %1.5f\n',xopt,i,err)
else
    fprintf('Maximum iterations reached.')
end
% 
%
%%
% *1c (10 points)*
%
% Let us consider another function $h(x) = x^3-6x^2+11x-5$. How many roots 
% does this function have? Plot this function for |x = (0.5:0.01:3.25)| to see visually.
% As in problem *1b* you can modify the function so that you can find 
% the roots using gradient descent.
% For modified function do all the minima correspond to the roots? What
% trouble can the gradient descent get into. Plot $h(x)$ and the modified
% function on the same plot to see this.
%
% *Answer*
%This function only has one root
%PLOTTING
h = @(x)(x.^3 - 6.*x.^2 + 11.*x - 5);
hMod = @(x)((x.^3 - 6.*x.^2 + 11.*x - 5).^2);
fig = fig+1;
figure(fig)
x = 0.5:0.01:3.25;
plot(x,h(x))
title('Graph of h(x)')
xlabel('x')
ylabel('y')
grid on
%
xopt = 1;
xopt_old = 1.2*xopt;

syms xsym
dhMod = matlabFunction(diff(hMod(xsym)));

i = 0;
maxi = 50;
tol = 1.E-6;
err = 1;
gamma = 0.01;

while err>tol && i < maxi
    xopt = xopt - gamma* dhMod(xopt);
    err = abs((xopt-xopt_old)/xopt);
    xopt_old = xopt;
    i = i+1;
    xopt_st(i) = xopt;
end

if (i<maxi)
    fprintf('Problem 1c:\nMinimum at x = %4.5f after %d iterations with err %1.5f\n',xopt,i,err)
else
    fprintf('Maximum iterations reached.')
end
%
% h(x) vs modified h(x)
fig = fig+1;
figure(fig);
x = 0.5:0.01:3.25;
plot(x,h(x),'-r',x,hMod(x),'-b')
title('h(x) vs modified h(x)')
xlabel('x')
ylabel('y')
grid on
%% Problem 2: Iterative Linear Solver (30 points)
%
% *2a (15 points)*
% You are given the following system of equations:
%
% $2x_{1} + 5x_{2} = 4$
%
% $4x_{1} + 3x_{2} = 1$
%
% The iterative solvers will not work if you try solving this system of 
% equations? Why? Modify the system so that you can use iterative linear 
% solver to find the solution $[x_{1} \quad x_{2}]^{T}$. Use Jacobi method
% with maximum iterations 50, tolerance of |1.E-6|, and 2-norm to evaluate
% the answer with an initial guess for $x =[0 \quad 0]^{T}$.
%
% *Answer*
A = [4 3; 2 5];
b = [1 4]';
x = A\b
%
tol = 1.E-6;
maxiter=50;
norm = 2;
n = length(A);
xinit = zeros(n,1);
fprintf('Problem 2a:')
jacobi(A,b,xinit,tol,maxiter,norm)
%%
% *2b (15 points)*
%
% Let us now consider the following system of equations:
%
% $2x_{1} + 5x_{2} + 1x_{3} = 4$
%
% $4x_{1} + 3x_{2} + 1x_{3}= 1$
%
% $7x_{1} + 6x_{2} + 1x_{3}= 2$
% 
% Can you use Jacobi method to solve the above system of equations? Why?
% What is the number of iterations that Jacobi method takes to solve the
% system with maximum iterations 100, tolerance of |1.E-6|, and 2-norm for 
% error calculation with an initial guess for $x =[0 \quad 0 \quad 0]^{T}$.
%
% *Answer*
A2 = [2 5 1; 4 3 1; 7 6 1];
b2 = [4 1 2]';
x = A2\b2;

tol = 1.E-6;
maxiter=100;
norm2 = 2;
n = length(A2);
xinit2 = zeros(n,1);
fprintf('Problem 2b:')
jacobi(A2,b2,xinit2,tol,maxiter,norm2)
%
% I don't believe the jacobi method will work because it consistently
% yields max iterations with high erorr.

% Maximum number of iterations are exceeded with high error, the answer is
% incorrect.
%% Problem 3: Least Squares Regression (40 points)
%
% *3a* (20 points)
%
% You are given the dataset (x1,y1) plotted below:
load P3a_data.mat
fig = fig+1;
figure(fig)
plot(x1,y1,'ob')
xlabel('x1')
ylabel('y1')
title('Problem 3a')
%%
% What polynomial order function will fit this data well? Output the regressed
% polynomial coefficients, and r^2 value in the command window.
% Display your regressed curve in the plot as a red line with the original
% data as blue circles.
%
% *Answer*
regress3a(x1, y1)

rsq2 = 0.8022;

n = length(x1);
X = [ones(n,1) x1 x1.^2 x1.^3 x1.^4];

a = (X'*X)\(X'*y1);

y_approx = a(1) + a(2)*x1 + a(3)*x1.^2 + a(4)*x1.^3 + a(5)*x1.^4;

scatter(x1,y1)
hold on
plot(x1,y_approx, 'r')
legend('data points', 'best fit curve')
title('3a with Best FIt')
xlabel('x')
ylabel('y')
hold off

%
%%
% *3b (20 points)*
%
% You are given the following multiple linear data with two independent
% (x2 with two columns) and one dependent data vectors (y2 with one column)
load P3b_data.mat
fig = fig+1;
figure(fig)
scatter3(x2(:,1),x2(:,2),y2,'ok')
xlabel('x2^{(1)}')
ylabel('x2^{(2)}')
zlabel('y2')
title('Problem 3b')
%not two linear lines, one coefficient and two slopes

regress3b(x2, y2)
%%
% Report the regressed multiple linear coefficients, and r^2 value in the
% output window. Plot the regressed plane on top of the scatter
% plot using |meshgrid()| to visulaize your fit.
%
% *Answer*

x21min = min(x2(:,1));
x21max = max(x2(:,1));
x22min = min(x2(:,2));
x22max = max(x2(:,2));

[xm_1, xm_2] = meshgrid(x21min:0.5:x21max, x22min:0.5:x22max);
%had to bring in outputted coefficients
a(1)=3.1913;
a(2)=1.01175;
a(3)=1.84268;
y_approx2 = @(xm_1, xm_2)(a(1) + a(2)*xm_1 + a(3)*xm_2);
Z=y_approx2(xm_1, xm_2);
figure(5)
scatter3(x2(:,1),x2(:,2),y2,'ok')
hold on
surf(xm_1, xm_2, y_approx2(xm_1, xm_2))
title('3b with Best FIt')
xlabel('x21')
ylabel('x22')
hold off

%
%%
%%FUNCTIONS%%
function [x,errst,iter] = jacobi(A,b,x,tol,maxiter,norm)
d = diag(A);
A = A - diag(d);

d = 1./d;
A = (A'*diag(d))';
b = b.*d;

err = 1.;
xold = x;
iter = 0;

while err>tol && iter<maxiter
    iter = iter + 1;
    x = b-A*x;
    errst(iter,:) = errnorm(x-xold)./errnorm(x);
    err = errst(iter,norm);
    
    xold = x;
end
fprintf('\n%d iterations with err %1.5f\n',iter,err)
if iter>=maxiter
    fprintf('\nLinear solver maxiter exceeded!!!\n')
end
end

function [abserr] =errnorm(vec)
    vec = abs(vec);
    abserr(1,1)= sum(vec);
    abserr(1,2) = sqrt(vec'*vec);
    abserr(1,3) = max(vec);
end

function [rsq] = regress3a(x, y)
n = length(x);
X = [ones(n,1) x x.^2 x.^3 x.^4];

a = (X'*X)\(X'*y);

y_approx = a(1) + a(2)*x + a(3)*x.^2 + a(4)*x.^3 + a(5)*x.^4;

St1 = sum((y-mean(y)).^2); % variance without x (Sy)
Sr1 = sum((y-y_approx).^2); % variance given x (Sy|x)
rsq = (St1-Sr1)/St1;

fprintf(' The coefficients for the 3a are %.5f, %.5f, %.5f, %.5f .', a(1), a(2), a(3), a(4));
fprintf( 'The coefficient of determination is %.5f .', rsq);
end

function [rsq2] = regress3b(x, y)
n = length(x);
X = [ones(n,1) x(:,1) x(:,2)];

a = (X'*X)\(X'*y);

y_approx2 = a(1) + a(2)*x(:,1) + a(3)*x(:,2);

St2 = sum((y-mean(y)).^2); % variance without x (Sy)
Sr2 = sum((y-y_approx2).^2); % variance given x (Sy|x)
rsq2 = (St2-Sr2)/St2;

fprintf(' The coefficients for the 3b are %.5f, %.5f, %.5f.', a(1), a(2), a(3));
fprintf( 'The coefficient of determination is %.5f .', rsq2);
end
